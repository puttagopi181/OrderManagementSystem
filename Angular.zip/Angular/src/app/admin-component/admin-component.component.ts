import { Component, OnInit } from '@angular/core';
import { OrderService } from '../orders.service';
import { Orders } from '../orders';
import { ActivatedRoute, Router } from '@angular/router';
import { ViewComponent } from '../view/view.component'
import { LoginServiceService } from '../login-service.service'

@Component({
  selector: 'app-admin-component',
  templateUrl: './admin-component.component.html',
  styleUrls: ['./admin-component.component.css']
})
export class AdminComponentComponent implements OnInit {
  orders: Orders[];
  confirmDelete = false;
  username: string;
  confirmed = false;
  orderid: number;

  constructor(private OrderService: OrderService,
    private _router: Router, private _route: ActivatedRoute,
    private loginservice: LoginServiceService) { }

  ngOnInit() {
    this.username = this._route.snapshot.paramMap.get('username');
    this.OrderService.getOrders().subscribe(
      data => { this.orders = data },
      err => console.error(err),
      () => console.log('done loading foods')
    );
    if (!this.loginservice.IsAdmin(this.username)) {
      this.LogOut1();
    }
  }
  LogOut = function (event) {
    console.log("hello");
    this._router.navigate(['/login']);
  }
  LogOut1() {
    this._router.navigate(['/login']);
  }
  CheckLog = function (event) {
    this.confirmDelete = true;
  }
  Reload = function (event) {
    this.confirmDelete = false;
  }
  DeleteOrder(orderid: number) {
    this.OrderService.DeleteOrder(this.orderid).subscribe(
      () => console.log(`Order with Id = ${this.orderid} deleted`),
      (err) => console.log(err));
    this.confirmed = false;
    this._router.navigate(['/admin', this.username]);
  }
  Confirm (id:number) {
    this.confirmed = true;
    this.orderid = id;
  }
  Reload1() {
    this.confirmed = false;
  }

}
