import { Injectable } from '@angular/core';
import { Orders } from './orders'
import { MaxLengthValidator } from '@angular/forms';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { catchError } from 'rxjs/operators';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { throwError } from 'rxjs'

// The @Injectable() decorator is used to inject other dependencies
// into this service. As our service does not have any dependencies
// at the moment, we may remove the @Injectable() decorator and the
// service works exactly the same way. However, Angular recomends
// to always use @Injectable() decorator to ensures consistency
@Injectable()
export class OrderService {
  private listOfOrders1: Orders[];
  baseurl = 'https://localhost:44369/api/details/order/get';
  baseurl1 = 'https://localhost:44369/delete/order';
  baseUrl2 = 'https://localhost:44369/api/neworder/post';
  baseUrledit = 'https://localhost:44369/api/putorder/put';
  constructor(private http: HttpClient) { }
  private listOfOrders: Orders[] = [
    {
      id: 1,
      name: "Headset",
      username: "hello",
      buyername: "Rajesjh",
      MobileNumber: "1234",
      Status: "Delivered",
      Address: "Hyd",
      image: "/assets/images/john.png"
    },
    {
      id: 2,
      name: "Pen",
      username: "puttagopi321",
      buyername: "Dinesh",
      MobileNumber: "1234",
      Status: "InProgress",
      Address: "Hyd",
      image: null
    },
    {
      id: 3,
      name: "Pencil",
      username: "puttagopi321",
      buyername: "Rajesjh",
      MobileNumber: "1234",
      Status: "Placed",
      Address: "Hyd",
      image:null
    },
  ];
  getOrders(): Observable<Orders[]> {
    console.log(this.baseurl);
    return this.http.get<Orders[]>(this.baseurl)
      .pipe(catchError(this.handleError));
  }
  getUserOrders(username: string) {
    this.getOrders().subscribe(
      data => { this.listOfOrders1 = data },
      err => console.error(err),
      () => console.log('done loading foods')
    );
    return this.listOfOrders1.filter(e => e.username == username);
  }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error: ', errorResponse.error.message);
    } else {
      console.error('Server Side Error: ', errorResponse);
    }

    return ErrorObservable.create(new Error("There is a problem with the service. We are notified & working on it. Please try again later."));
  }


  //DeleteOrder(orderid: number) {
  //  const i = this.listOfOrders.findIndex(e => e.id === orderid)
  //  if (i !== -1) {
  //    this.listOfOrders.splice(i, 1);
  //  }
  //}

  DeleteOrder(orderid: number): Observable<void> {
    console.log(orderid);

    return this.http.get<void>(`${this.baseurl1}/${orderid}`)
      .pipe(catchError(this.handleError));
  }

  save(newitem: Orders) {
    let maxValue = Math.max.apply(Math, this.listOfOrders.map(function (o) { return o.id; }));
    maxValue = maxValue + 1;
    newitem.id = maxValue;
    this.PostOrder(newitem).subscribe(
      (data: Orders) => {
        console.log(data);
      },
      (error: any) => console.log(error)
    );
  }
  PostOrder(newitem: Orders): Observable<Orders> {
    console.log("vachhindi");
    return this.http.post<Orders>(this.baseUrl2, newitem
      , {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      })
      .pipe(catchError(this.handleError));
  }
  
  UpdateOrder(newitem: Orders): Observable<void> {
    return this.http.put<void>(this.baseUrledit, newitem, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
      .pipe(catchError(this.handleError));
  }

}
