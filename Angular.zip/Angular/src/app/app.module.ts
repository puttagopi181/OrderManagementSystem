import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { LoginServiceService } from './login-service.service';
import { ItemService } from './items.service'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponentComponent } from './admin-component/admin-component.component';
import { NullComponentComponent } from './null-component/null-component.component';
import { OrderService } from './orders.service';
import { UserComponent } from './user/user.component';
import { ViewComponent } from './view/view.component';
import { NewitemComponent } from './newitem/newitem.component';
import { NeworderComponent } from './neworder/neworder.component'
import { HttpClientModule } from '@angular/common/http';
import { EditorderComponent } from './editorder/editorder.component';



const appRoutes: Routes = [
  {
    path: '',
    component: LoginComponent,
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent,
    pathMatch: 'full'
  },
  {
    path: 'admin/:username',
    component: AdminComponentComponent,
    pathMatch:'full'
  },
  {
    path: 'user/:username',
    component: UserComponent,
    pathMatch: 'full'
  },
  {
    path: 'view',
    component: ViewComponent,
    pathMatch: 'full'
  },
  {
    path: 'newitem',
    component: NewitemComponent,
    pathMatch: 'full'
  },
  {
    path: 'neworder',
    component: NeworderComponent,
    pathMatch: 'full'
  },
  {
    path: 'editorder',
    component: EditorderComponent,
    pathMatch: 'full'
  },
];


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AdminComponentComponent,
    NullComponentComponent,
    UserComponent,
    ViewComponent,
    NewitemComponent,
    NeworderComponent,
    EditorderComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [LoginServiceService, OrderService, ItemService],
  bootstrap: [AppComponent]
})
export class AppModule { }
