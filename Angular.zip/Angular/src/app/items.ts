export class Items {
  orderid: number;
  itemsname: string;
  weight: string;
  height: string;
  SKU: string;
  barcode: string;
}
