import { Items } from './items';

describe('Items', () => {
  it('should create an instance', () => {
    expect(new Items()).toBeTruthy();
  });
});
