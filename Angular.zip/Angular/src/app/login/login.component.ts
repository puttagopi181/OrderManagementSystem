import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Type } from '../type';
import { Login } from '../login'
import { Login1 } from '../login1'
import { LoginServiceService } from '../login-service.service';
import { ViewChild } from '@angular/core';
import { Observable } from 'rxjs/Rx';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  message: string;

  //user: Login;;
  check: boolean;

  user: Login1 = {
    username: null,
    password: null
  };

  listofusers: Login[];


  constructor(private LoginService: LoginServiceService,
    private _router: Router,
    private _route: ActivatedRoute) { }

  @ViewChild('LoginForm,', { static: true }) form: NgForm;
  ngOnInit() {
    this.LoginService.getEmployees().subscribe(
      data => { this.listofusers = data },
            err => console.error(err),
            () => console.log('done loading foods')
          );
  }


  LoginDeatils(): void {
    console.log(this.listofusers);
    const hello = this.listofusers.find(e =>
      e.username == this.user.username
      && e.password == this.user.password
    );
    if (hello != null) {

      if (hello.type == 1) {
        this._router.navigate(['/admin', this.user.username]);
      }
      else {
        this._router.navigate(['/user', this.user.username]);

      }
    }
    else {
      console.log("hello");
      this.message = "UserName or Password is Incorrect"
      this.form.resetForm();
      this._router.navigate(["/login"]);
    }

    //  if (hello.username != null) {

    //  }
    //  else {
    //    this._router.navigate(["login"]);
    //  }

    //}
    //if (this.user.type == 2) {

    //}


  }
}
