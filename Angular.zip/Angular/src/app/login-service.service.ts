import { Injectable } from '@angular/core';
import { Login } from './login'
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { catchError } from 'rxjs/operators';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { throwError } from 'rxjs'


// The @Injectable() decorator is used to inject other dependencies
// into this service. As our service does not have any dependencies
// at the moment, we may remove the @Injectable() decorator and the
// service works exactly the same way. However, Angular recomends
// to always use @Injectable() decorator to ensures consistency
@Injectable()
export class LoginServiceService {
  private listofusers: Login[];
  baseurl = 'https://localhost:44369/api/details/get';
  constructor(private http: HttpClient) {}
  private listEmployees: Login[] = [
    {
      type: 1,
      username: "puttagopi123",
      password: "rgukt123"
    },
    {
      type: 2,
      username: "puttagopi321",
      password: "rgukt321"
    },
    {
      type: 1,
      username: "puttagopi322",
      password: "rgukt322"
    },
    {
      type: 2,
      username: "hello",
      password: "hello"
    },
  ];

  getEmployees(): Observable<Login[]> {
    console.log(this.baseurl);
    return this.http.get<Login[]>(this.baseurl)
      .pipe(catchError(this.handleError));
  }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error: ', errorResponse.error.message);
    } else {
      console.error('Server Side Error: ', errorResponse);
    }

    return ErrorObservable.create(new Error("There is a problem with the service. We are notified & working on it. Please try again later."));
  }

  getUsers(): Observable<Login[]> {
    return this.http.get<Login[]>(this.baseurl)
      .pipe(catchError(this.handleError));
  }
  IsAdmin(username: string): boolean {
    this.getEmployees().subscribe(
      data => { this.listofusers = data },
      err => console.error(err),
      () => console.log('done loading foods')
    );
    if (this.listEmployees.find(e => e.username == username && e.type == 1)) {
      return true;
    }
    return false;
  }
}
