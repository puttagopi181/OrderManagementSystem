export class Login {
  type: number;
  username: string;
  password: string;

}
