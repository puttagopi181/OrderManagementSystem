import { Login1 } from './login1';

describe('Login1', () => {
  it('should create an instance', () => {
    expect(new Login1()).toBeTruthy();
  });
});
