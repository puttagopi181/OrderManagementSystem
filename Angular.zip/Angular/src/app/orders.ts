export class Orders {
  id: number;
  name: string;
  username: string;
  buyername: string;
  MobileNumber: string;
  Status: string;
  Address: string;
  image: string;

}
