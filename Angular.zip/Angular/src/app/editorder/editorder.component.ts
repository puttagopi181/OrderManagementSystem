import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { OrderService } from '../orders.service'
import { Orders } from '../orders';

@Component({
  selector: 'app-editorder',
  templateUrl: './editorder.component.html',
  styleUrls: ['./editorder.component.css']
})
export class EditorderComponent implements OnInit {
  username: string;
  orderid: number;
  orders: Orders[];
  //order: Orders = {
  //  id: null,
  //  name: null,
  //  username: this.username,
  //  buyername: null,
  //  MobileNumber: null,
  //  Status: null,
  //  Address: null,
  //  image: null
  //}
  order: Orders=
    {
      id: 1,
      name: "Headset",
      username: "hello",
      buyername: "Rajesjh",
      MobileNumber: "1234",
      Status: "Delivered",
      Address: "Hyd",
      image: "/assets/images/john.png"
     }
  constructor(private orderserivce: OrderService,
    private _route: ActivatedRoute,
    private _router: Router) { }

  ngOnInit() {
    this.username = this._route.snapshot.paramMap.get('username');
    this.orderid = + this._route.snapshot.paramMap.get('id');
    console.log(this.username);
    console.log(this.orderid);
    //this.orderserivce.getOrders().subscribe(
    //  data => { this.orders = data },
    //  err => console.error(err),
    //  () => console.log('done loading foods4')
    //);
    //this.order = this.orders.find(e => e.id == this.orderid);
    //console.log(this.order.id);
  }
  BackToList() {
      this._router.navigate(['/admin', this.username]);
  }
  UpdateDetails() {
    this.order.id = this.orderid;
    console.log(this.order);
    this.orderserivce.UpdateOrder(this.order).subscribe(
      () => console.log(`Employee with Id = ${this.orderid} Updated`),
      (err) => console.log(err)
    );
    this.BackToList();
  }
}
