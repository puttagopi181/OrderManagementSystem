import { Component, OnInit } from '@angular/core';
import { ItemService } from '../items.service'
import { LoginServiceService } from '../login-service.service'
import { Router, ActivatedRoute } from '@angular/router';
import { Items } from '../items';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { catchError } from 'rxjs/operators';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { throwError } from 'rxjs'


@Component({
  selector: 'app-newitem',
  templateUrl: './newitem.component.html',
  styleUrls: ['./newitem.component.css']
})
export class NewitemComponent implements OnInit {

  orderid: number;
  username: string;
  item: Items = {
    orderid: this.orderid,
    itemsname: null,
    weight: null,
    height: null,
    SKU: null,
    barcode:null
  };

  constructor(private itemservice: ItemService, private loginservice: LoginServiceService,
    private _route: ActivatedRoute,
    private _router: Router) { }

  ngOnInit() {
    this.orderid = +this._route.snapshot.paramMap.get('id');
    this.username = this._route.snapshot.paramMap.get('username');
  }

  BackToList() {
    if (this.loginservice.IsAdmin(this.username)) {
      this._router.navigate(['/admin', this.username]);
    }
    else {
      this._router.navigate(['/user', this.username]);
    }
  }
  NewItemDeatils(): void {
    this.item.orderid = this.orderid;
    console.log(this.item);
    this.itemservice.save(this.item);
    this.BackToList();

  }
}
