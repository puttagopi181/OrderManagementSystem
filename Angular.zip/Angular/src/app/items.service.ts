import { Injectable } from '@angular/core';
import { Items } from './items'
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { throwError } from 'rxjs'
import { catchError } from 'rxjs/operators';

// The @Injectable() decorator is used to inject other dependencies
// into this service. As our service does not have any dependencies
// at the moment, we may remove the @Injectable() decorator and the
// service works exactly the same way. However, Angular recomends
// to always use @Injectable() decorator to ensures consistency
@Injectable()
export class ItemService {
  constructor(private http: HttpClient) { }
  baseUrl = 'https://localhost:44369/api/details/items/get';
  baseUrl1 = 'https://localhost:44369/api/newitem/post';
  private listOfItems1: Items[];
  private listOfItems: Items[] = [
    {
      orderid: 1,
      itemsname: "Pen",
      weight: "100g",
      height: "3ft",
      SKU: "unknown",
      barcode:"###"
    },
    {
      orderid: 1,
      itemsname: "Pencil",
      weight: "100g",
      height: "3ft",
      SKU: "unknown",
      barcode: "###"
    },
    {
      orderid: 1,
      itemsname: "chocolate",
      weight: "100g",
      height: "3ft",
      SKU: "unknown",
      barcode: "###"
    },
    {
      orderid: 2,
      itemsname: "Pen",
      weight: "100g",
      height: "3ft",
      SKU: "unknown",
      barcode: "###"
    },
    {
      orderid: 2,
      itemsname: "Pencil",
      weight: "100g",
      height: "3ft",
      SKU: "unknown",
      barcode: "###"
    },
    {
      orderid: 2,
      itemsname: "chocolate",
      weight: "100g",
      height: "3ft",
      SKU: "unknown",
      barcode: "###"
    },
    {
      orderid: 3,
      itemsname: "Pen",
      weight: "100g",
      height: "3ft",
      SKU: "unknown",
      barcode: "###"
    },
    {
      orderid: 3,
      itemsname: "Pencil",
      weight: "100g",
      height: "3ft",
      SKU: "unknown",
      barcode: "###"
    },
    {
      orderid: 3,
      itemsname: "chocolate",
      weight: "100g",
      height: "3ft",
      SKU: "unknown",
      barcode: "###"
    },
  ];

  getAllItems(): Observable<Items[]> {
    return this.http.get<Items[]>(this.baseUrl)
      .pipe(catchError(this.handleError))
  }

  private handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error instanceof ErrorEvent) {
      console.error('Client Side Error: ', errorResponse.error.message);
    } else {
      console.error('Server Side Error: ', errorResponse);
    }

    return ErrorObservable.create(new Error("There is a problem with the service. We are notified & working on it. Please try again later."));
  }

  getitems(orderid: number): Items[] {
    this.getAllItems().subscribe(
      data => { this.listOfItems1 = data },
      err => console.error(err),
      () => console.log('done loading foods')
    );
    return this.listOfItems1.filter(e => e.orderid == orderid);
  }
  save(newitem: Items) {
    console.log(newitem);
    this.PostItem(newitem).subscribe(
      (data: Items) => {
        console.log(data);
      },
      (error: any) => console.log(error)
    );
  }
  PostItem(newitem: Items): Observable<Items> {
    console.log("vachhindi");
    return this.http.post<Items>(this.baseUrl1, newitem
      , {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    })
      .pipe(catchError(this.handleError));
  }
}
