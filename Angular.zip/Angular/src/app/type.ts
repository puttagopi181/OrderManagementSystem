export class Type {
  id: number;
  name: string;
}
