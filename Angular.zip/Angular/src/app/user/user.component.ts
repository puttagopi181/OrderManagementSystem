import { Component, OnInit, EventEmitter } from '@angular/core';
import { OrderService } from '../orders.service';
import { Orders } from '../orders';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  username: string;
  userorders: Orders[];
  confirmDelete: false;
  confirmed = false;
  orderid: number;


  constructor(private OrderService: OrderService,
    private _router: Router, private _route: ActivatedRoute) { }

  ngOnInit() {
    this.username = this._route.snapshot.paramMap.get('username');
    this.userorders = this.OrderService.getUserOrders(this.username);
    console.log(this.userorders);
  }
  LogOut=function(event) {
    console.log("hello");
    this._router.navigate(['/login']);
  }
  CheckLog = function (event) {
    this.confirmDelete = true;
  }
  Reload = function (event) {
    this.confirmDelete = false;
  }
  DeleteOrder(orderid: number) {
    this.OrderService.DeleteOrder(this.orderid).subscribe(
      () => console.log(`Employee with Id = ${this.orderid} deleted`),
      (err) => console.log(err)
    );
    console.log(orderid);
    this.confirmed = false;
    this._router.navigate(['/user', this.username]);
  }
  Confirm(id: number) {
    this.confirmed = true;
    this.orderid = id;
  }
  Reload1() {
    this.confirmed = false;
  }
}
