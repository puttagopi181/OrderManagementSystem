import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-null-component',
  templateUrl: './null-component.component.html',
  styleUrls: ['./null-component.component.css']
})
export class NullComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
