export class Userdetails {
}
