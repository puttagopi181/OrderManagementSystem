import { Component, OnInit } from '@angular/core';
import { ItemService } from '../items.service'
import { LoginServiceService } from '../login-service.service'
import { Router, ActivatedRoute } from '@angular/router';
import { Items } from '../items';


@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  orderid: number;
  username: string;
  items: Items[];

  constructor(private itemservice: ItemService, private loginservice: LoginServiceService,
    private _route: ActivatedRoute,
    private _router: Router) { }

  ngOnInit() {
    this.orderid = +this._route.snapshot.paramMap.get('id');
    this.username = this._route.snapshot.paramMap.get('username');
    this.items = this.itemservice.getitems(this.orderid);
    //if (this.loginservice.IsAdmin(this.username)) {
    //  this.IsAdmin = true;
    //}
    //else {
    //  this.IsAdmin = false;
    //}
    
  }
  BackToList() {
    if (this.loginservice.IsAdmin(this.username)) {
      this._router.navigate(['/admin', this.username]);
    }
    else {
      this._router.navigate(['/user', this.username]);
    }
  }
}
