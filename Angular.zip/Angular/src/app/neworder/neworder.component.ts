import { Component, OnInit } from '@angular/core';
import { OrderService } from '../orders.service';
import { Orders } from '../orders';
import { ItemService } from '../items.service';
import { LoginServiceService } from '../login-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-neworder',
  templateUrl: './neworder.component.html',
  styleUrls: ['./neworder.component.css']
})
export class NeworderComponent implements OnInit {
  username: string;
  order: Orders = {
    id: null,
    name: null,
    username: this.username,
    buyername: null,
    MobileNumber: null,
    Status: null,
    Address: null,
    image:null
  }

  constructor(private itemservice: ItemService, private loginservice: LoginServiceService,
    private orderservice: OrderService,
    private _route: ActivatedRoute,
    private _router: Router) { }

  ngOnInit() {
    this.username = this._route.snapshot.paramMap.get('username');
  }
  BackToList() {
    if (this.loginservice.IsAdmin(this.username)) {
      this._router.navigate(['/admin', this.username]);
    }
    else {
      this._router.navigate(['/user', this.username]);
    }
  }
  NewOrderDeatils() {
    this.order.username = this.username;
    this.order.Status = "Placed";
    this.orderservice.save(this.order);
    this.BackToList();
  }
}
