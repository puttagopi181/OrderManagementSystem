export class Login1 {
  username: string;
  password: string;
}
