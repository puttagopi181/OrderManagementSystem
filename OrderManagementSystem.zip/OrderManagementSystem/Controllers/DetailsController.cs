﻿using OrderManagementSystem.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Routing;

namespace OrderManagementSystem.Controllers
{
    public class DetailsController : ApiController
    {
        public int one = 10;
        List<Order> listofOrders = new List<Order>() {
            new Order
            {
             id=1,
      name="Headset",
      username="hello",
      buyername="Rajesjh",
      MobileNumber="1234",
      Status= "Delivered",
      Address= "Hyd",
      image= "/assets/images/john.png"
            },new Order
            {
                id= 2,
      name= "Pen",
      username= "puttagopi321",
      buyername= "Dinesh",
      MobileNumber= "1234",
      Status= "InProgress",
      Address= "Hyd",
      image= null
            },new Order
            {
                id= 3,
      name= "Pencil",
      username= "puttagopi321",
      buyername= "Rajesjh",
      MobileNumber= "1234",
      Status= "Placed",
      Address= "Hyd",
      image=null
            }
        };
        
        [HttpGet,Route("delete/order/{orderid}")]
        public IHttpActionResult Delete(int orderid)
        {
            var order = listofOrders.Where(t => t.id == orderid).FirstOrDefault();
            if (order == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }

            listofOrders.Remove(order);
            return Ok();
        }

        public IEnumerable<Login> GetUsers()
        {
            List<Login> listofusers = new List<Login>();

            listofusers.Add(new Login{ type = 1,username="puttagopi123",password="rgukt123" });
            listofusers.Add(new Login { type = 2, username = "puttagopi321", password = "rgukt321" });
            listofusers.Add(new Login { type = 1, username = "puttagopi322", password = "rgukt322" });
            listofusers.Add(new Login { type = 2, username = "hello", password = "hello" });
            return listofusers;
        }
        [Route("api/details/order/get")]
        public IEnumerable<Order> Get()
        {
            return listofOrders;
        }
        [Route("api/details/items/get")]
        public IEnumerable<Items> GetItems()
        {
            List<Items> listofitems = new List<Items>();
            listofitems.Add(new Items {orderid= 1,
      itemsname= "Pen",
      weight= "100g",
      height= "3ft",
      SKU= "unknown",
      barcode="###" });
            listofitems.Add(new Items {orderid= 1,
      itemsname= "Pencil",
      weight= "100g",
      height= "3ft",
      SKU= "unknown",
      barcode= "###" });

            listofitems.Add(new Items {orderid= 1,
      itemsname= "chocolate",
      weight= "100g",
      height= "3ft",
      SKU= "unknown",
      barcode= "###" });

            listofitems.Add(new Items { orderid= 2,
      itemsname= "Pen",
      weight= "100g",
      height= "3ft",
      SKU= "unknown",
      barcode= "###"});

            listofitems.Add(new Items { orderid= 2,
      itemsname= "Pencil",
      weight= "100g",
      height= "3ft",
      SKU= "unknown",
      barcode= "###" });


            listofitems.Add(new Items {orderid= 2,
      itemsname= "chocolate",
      weight= "100g",
      height= "3ft",
      SKU= "unknown",
      barcode= "###" });

            listofitems.Add(new Items {orderid= 3,
      itemsname= "Pen",
      weight= "100g",
      height= "3ft",
      SKU= "unknown",
      barcode= "###" });

            listofitems.Add(new Items {orderid= 3,
      itemsname= "Pencil",
      weight= "100g",
      height= "3ft",
      SKU= "unknown",
      barcode= "###" });

            listofitems.Add(new Items {orderid= 3,
      itemsname= "chocolate",
      weight= "100g",
      height= "3ft",
      SKU= "unknown",
      barcode= "###" });

            return listofitems;
        }
        //[Route("api/details/orders/del")]

        [HttpPost,Route("api/newitem/post")]
        public IHttpActionResult PostItem(Items item)
        {
            List<Items> listofitems = new List<Items>();
            listofitems = this.GetItems().ToList();
            listofitems.Add(item);
            return Ok();
        }
        [HttpPost, Route("api/neworder/post")]
        public IHttpActionResult PostOrder(Items item)
        {
            List<Items> listofitems = new List<Items>();
            listofitems = this.GetItems().ToList();
            listofitems.Add(item);
            return Ok();
        }

        [Route("api/putorder/put")]
        public IHttpActionResult Put(Order order)
        {
                var existingStudent = listofOrders.Where(s => s.id == order.id)
                                                        .FirstOrDefault<Order>();
            int existingStudent1 = listofOrders.IndexOf(listofOrders.Where(e=>e.id==order.id).FirstOrDefault());
            if (existingStudent != null)
                {
                existingStudent.image = order.image;
                 existingStudent.MobileNumber = order.MobileNumber;
                existingStudent.image = order.name;
                existingStudent.Status = order.Status;
                    
                }
                else
                {
                    return NotFound();
                }
            listofOrders.RemoveAt(existingStudent1);
            listofOrders.Add(existingStudent);
            return Ok();
        }

    }
}
