﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderManagementSystem.Models
{
    public class Order
    {
    public int id {get;set;}     
    public string name { get; set; }
    public string username { get; set; }
    public string buyername { get; set; }
    public string MobileNumber { get; set; }
    public string Status { get; set; }
    public string Address { get; set; }
    public string image { get; set; }
    }
}
