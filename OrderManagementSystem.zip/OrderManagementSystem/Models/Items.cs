﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderManagementSystem.Models
{
    public class Items
    {
        public int orderid { get; set; }
        public string itemsname { get; set; }
        public string weight { get; set; }
        public string height { get; set; }
        public string SKU { get; set; }
        public string barcode { get; set; }
    }
}